package com.thazin.citiesapp

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG  = MainViewModel::class.simpleName
    private var citiesLiveData: MutableLiveData<ArrayList<City>> = MutableLiveData()
    private val context = getApplication<Application>().applicationContext

    init {
        Log.i(TAG, "MainViewModelCreated")
    }

    fun getCityList() : MutableLiveData<ArrayList<City>> {

        return MutableLiveData<ArrayList<City>>(Utils.getCities(context))
    }

    override fun onCleared() {
        super.onCleared()
        Log.i(TAG, "onCleared: GameViewModel destroyed!")
    }
}