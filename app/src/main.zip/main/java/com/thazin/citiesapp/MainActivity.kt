package com.thazin.citiesapp

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.thazin.citiesapp.ui.adapter.CityAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private val TAG = MainActivity::class.simpleName
    private lateinit var viewModel: MainViewModel
    private lateinit var linearLayoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.i(TAG, "Called ViewModelProvider.get")
        progress_bar.visibility = View.VISIBLE

        sv_city.isIconified = false
//        sv_city.setOnClickListener {
//            sv_city.isIconified = false
//        }

        linearLayoutManager = LinearLayoutManager(this)
        rv_cities.layoutManager = linearLayoutManager

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        viewModel.getCityList().observe(this, Observer {
            cityList ->
            progress_bar.visibility = View.GONE
            Log.d(TAG, "onCreate: "+Gson().toJson(cityList))
            rv_cities.adapter = CityAdapter (cityList, this)
        })
    }
}