package com.thazin.citiesapp

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.IOException

class Utils {

    companion object {
        fun getCities(context: Context): ArrayList<City> {
            val fileInString: String =
                context.assets.open("cities.json").bufferedReader().use {
                    it.readText()
                }
            val listCity = object : TypeToken<List<City>>() {}.type
            return Gson().fromJson(fileInString, listCity)
        }
    }

}