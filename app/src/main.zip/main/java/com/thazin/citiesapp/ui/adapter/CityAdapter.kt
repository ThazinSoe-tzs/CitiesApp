package com.thazin.citiesapp.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.thazin.citiesapp.City
import com.thazin.citiesapp.R
import kotlinx.android.synthetic.main.item_city.view.*

class CityAdapter(private var cityList: ArrayList<City>, private val context: Context) : RecyclerView.Adapter<CityAdapter.CityViewHolder>(), Filterable {
    class CityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindItems(city: City){
            itemView.tv_title!!.text = city.name
            "lon ${city.coord.lon}, lat ${city.coord.lat}".also { itemView.tv_sub_title!!.text = it }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        return CityViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_city,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        holder.bindItems(cityList[position])
    }

    override fun getItemCount(): Int {
        return cityList.size
    }

    override fun getFilter(): Filter {
        TODO("Not yet implemented")
    }
}


